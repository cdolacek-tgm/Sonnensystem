﻿.. Solarsystem by Özer&Dolacek documentation master file, created by
   sphinx-quickstart on Sun Mar 29 16:18:24 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


=============   
   
.. image:: ../../Resources/titel.png
	
:download:`Das Protkoll für das Solarsystem können sie hier aufrufen<../../Protokoll/Özer_Dolacek_Protokoll.pdf>`

Klassen:
--------

.. toctree::
   :maxdepth: 2

   starter.rst	
   splashscreen.rst	
   solarsystem.rst	
   planet.rst	
   textur.rst	
   licht.rst	
   interaction.rst	
   gui.rst	
   uml.rst	
   test_starter.rst	
   test_splashscreen.rst	
   test_solarsystem.rst	
   test_planet.rst	
   test_textur.rst	
   test_licht.rst	
   test_interaction.rst		

Indices and tables
==================

* :ref:`genindex`