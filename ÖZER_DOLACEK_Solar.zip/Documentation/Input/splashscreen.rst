﻿.. Solarsystem by Özer&Dolacek documentation master file, created by
   sphinx-quickstart on Sun Mar 29 16:18:24 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Splashscreen
============

Die Klasse Splashscreen ist quasi eine Einführung in unser Solarsystem.
Dem User werden 3 Menüpunkte angezeigt:

1. Solarsystem
2. Steuerung
3. Beenden

Dokumentation
-------------

.. py:currentmodule:: splashscreen
.. autoclass:: Splashscreen
	:members: