﻿.. Solarsystem by Özer&Dolacek documentation master file, created by
   sphinx-quickstart on Sun Mar 29 16:18:24 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

TestSolarsystem
===============

Hier werden die Objekte überprüft, ob sie wirklich der entsprechenden Klasse gehören.

Dokumentation
-------------

.. py:currentmodule:: test_solarsystem
.. autoclass:: TestSolarsystem
	:members:
