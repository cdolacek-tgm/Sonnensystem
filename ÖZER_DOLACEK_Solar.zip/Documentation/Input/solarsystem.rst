﻿.. Solarsystem by Özer&Dolacek documentation master file, created by
   sphinx-quickstart on Sun Mar 29 16:18:24 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Solarsystem
===========

Für die Anzeige, Benutzersteuerung und Kameraperspektive ist die Klasse Solarsystem dafür zuständig

Dokumentation
-------------

.. py:currentmodule:: solarsystem
.. autoclass:: Solarsystem
	:members: