﻿.. Solarsystem by Özer&Dolacek documentation master file, created by
   sphinx-quickstart on Sun Mar 29 16:18:24 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

TestTextur
==========

Hier werden die Maus- und Tastensteuerung überprüft

Dokumentation
-------------

.. py:currentmodule:: test_interaction
.. autoclass:: TestInteraction
	:members:
