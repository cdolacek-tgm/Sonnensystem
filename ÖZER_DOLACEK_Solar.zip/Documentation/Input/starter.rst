﻿.. Solarsystem by Özer&Dolacek documentation master file, created by
   sphinx-quickstart on Sun Mar 29 16:18:24 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Starter
=======

Der Starter führt das ganze Programm aus 

Dokumentation
-------------

.. py:currentmodule:: starter
.. autoclass:: Starter
	:members:
