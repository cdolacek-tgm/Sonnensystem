from unittest import TestCase
from interaction import *

__author__ = 'Cafer Özer'

class TestInteraction(TestCase):
    def test_keyPressed(self):
        self.fail()

    def test_mouse(self):
        self.fail()