SOLARSYSTEM BY �ZER & DOLACEK:
==============================

HOW TO USE:
-----------


1) Install Python 3.3(or higher) on your system

----------------------------------------------------

2) Install all plugins which is in the "Libaries" folder.
   Be careful by installing the right version!
 
   For example, if you install 64bit python, you will install the plugins in 64bit.
	
	o) Pillow
	O) PyOpenGL
	o) PyGame
	o) FreeGlut*

	*It's only a .dll file which is not installable.
	 It must be in the same folder as the starter.py and so on. 

----------------------------------------------------------------------------------

3) If the installations were clean of problems, 
   you should able to launch the "starter.py"-file without any issues.
----------------------------------------------------------------------

4) HAVE FUN !

-------------