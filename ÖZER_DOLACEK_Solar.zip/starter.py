__author__ = 'Cafer Özer'

from splashscreen import *

class Starter():
    def main():
        """
        Erstellt ein Objekt zur Klasse Splashscreen, führt anschließend das Solarsystem aus
        """
        test = Splashscreen()
        test.main()

    if __name__ == '__main__':
        main()